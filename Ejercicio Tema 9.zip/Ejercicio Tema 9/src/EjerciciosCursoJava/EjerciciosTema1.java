package EjerciciosCursoJava;

public class EjerciciosTema1 {
    public static void main(String[] args) {
        // números
        byte numero1 = 1;
        short numero2 = 2;
        int numero3 = 3;
        long numero4 = 4;
        float numero5 = 1.2f;
        double numero6 = 5.7;
        Integer numero7 = 7;
        Long numero8 =  8L;

        // carácter
        char caracter1 = 'a';

        // booleanos
        boolean verdadero = true;

        // cadenas de texto
        String cadenaDeTexto = "Hola Mundo";

        // Mostrar los datos en pantalla
        System.out.println(numero1 + " " + numero2 + " " + numero3 + " " + numero4 + " " + numero5 + " " + numero6 + " " + numero7 + " " + numero8 + " " + caracter1 + " " + verdadero + " " + cadenaDeTexto);

    }
}
